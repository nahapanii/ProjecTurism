﻿using Microsoft.AspNetCore.Identity;

namespace TourismProjectDb.Models
{
    public class User : IdentityUser
    {
        public List<TouristObject> ReservedObjects { get; set; } = new();
    }
}
