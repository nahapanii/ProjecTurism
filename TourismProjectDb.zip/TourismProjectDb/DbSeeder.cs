﻿using TourismProjectDb.Models;

namespace TourismProjectDb
{
    public static class DbSeeder
    {
        public static void Seed(ApplicationContext context)
        {
            if (!context.TouristObjects.Any()) 
            {
                var list = new List<TouristObject>()
                {
                    new TouristObject()
                    {
                        Description = "Даргавс — это уникальный архитектурный комплекс из множества старинных склепов, расположенных на склонах живописной долины.",
                        Name = "Даргавс — Город мертвых",
                        Price = 2500,
                        ImagePath = "img/dargavs.jpg"
                    },
                    new TouristObject()
                    {
                        Description = "Куртатинское ущелье — одно из самых живописных мест в Северной Осетии, окруженное высокими скалами и зелеными лесами.",
                        Name = "Куртатинское ущелье",
                        Price = 3000,
                        ImagePath = "/img/kurtatinskoe.jpg"
                    },
                    new TouristObject()
                    {
                        Description = "Аланский Свято-Успенский мужской монастырь — это один из самых значимых религиозных центров Кавказа.",
                        Name = "Аланский монастырь",
                        Price = 2000,
                        ImagePath = "/img/alansky_monastery.jpg"
                    },
                    new TouristObject()
                    {
                        Description = "Кольцо Дзинага — это природная арка, созданная ветром и эрозией в известняковых скалах.",
                        Name = "Кольцо Дзинага",
                        Price = 3500,
                        ImagePath = "/img/dzina_ring.jpg"
                    },
                    new TouristObject()
                    {
                        Description = "Мидаграбинские водопады — это группа из нескольких живописных водопадов, расположенных в горной местности.",
                        Name = "Мидаграбинские водопады",
                        Price = 4000,
                        ImagePath = "/img/midagrabin_waterfalls.jpg"
                    },
                    new TouristObject()
                    {
                        Description = "Алагирское ущелье — это место, где можно насладиться потрясающими видами на Кавказские горы и реки.",
                        Name = "Алагирское ущелье",
                        Price = 3000,
                        ImagePath = "/img/alagir_gorge.jpg"
                    },
                    new TouristObject()
                    {
                        Description = "Цейское ущелье — это живописная долина с ледниками, горными вершинами и альпийскими лугами.",
                        Name = "Цейское ущелье",
                        Price = 5000,
                        ImagePath = "/img/tsey_gorge.jpg"
                    },
                    new TouristObject()
                    {
                        Description = "Фиагдонское ущелье — одно из самых популярных туристических мест в Северной Осетии.",
                        Name = "Фиагдонское ущелье",
                        Price = 2500,
                        ImagePath = "/img/fiagdon_gorge.jpg"
                    }
                };
                context.AddRange(list);
                context.SaveChanges();
            }
        }
    }
}
