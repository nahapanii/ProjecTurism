﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using TourismProjectDb;
using TourismProjectDb.Models;

namespace TourismProject.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddServices(
            this IServiceCollection services, 
            string connectionString)
        {
            services.AddDbContext<ApplicationContext>(options =>
            {
                options.UseSqlServer(connectionString);
            });
            services.AddIdentity<User, IdentityRole>(options =>
            {
                options.User.RequireUniqueEmail = true;
            }).AddEntityFrameworkStores<ApplicationContext>();
            return services;
        }
    }
}
