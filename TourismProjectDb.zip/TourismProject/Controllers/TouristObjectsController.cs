﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using TourismProject.Models;
using TourismProjectDb;
using TourismProjectDb.Models;

namespace TourismProject.Controllers
{
    public class TouristObjectsController : Controller
    {
        private readonly ApplicationContext _context;
        public TouristObjectsController(
            ApplicationContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> AllObjects()
        {
            var objects = await _context.TouristObjects
                .Select(x => new TouristObjectViewModel()
                {
                    Id = x.Id,
                    Name = x.Name,
                    ImagePath = x.ImagePath,
                    Price = x.Price
                })
                .ToArrayAsync();
            return View(objects);
        }
        [HttpGet]
        [Route("/detailed/{id}")]
        public async Task<IActionResult> DetailedObject(int id)
        {
            var userId = HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            userId = userId is null ? string.Empty : userId;
            var detailedObject = await _context.TouristObjects
                .Select(x => new DetailedTouristObjectViewModel()
                {
                    Id = x.Id,
                    Name = x.Name,
                    ImagePath = x.ImagePath,
                    Price = x.Price,
                    Description = x.Description,
                    IsReservedByUser = _context.Users.Any(y => y.Id == userId && y.ReservedObjects.Any(c => c.Id == x.Id))
                }).FirstOrDefaultAsync(x => x.Id == id);
            return View(detailedObject);
        }
        [Authorize]
        [HttpGet]
        [Route("reserve/{id}")]
        public async Task<IActionResult> AddToReserved(int id)
        {
            var userId = HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = await _context.Users
                .Include(x => x.ReservedObjects)
                .FirstOrDefaultAsync(x => x.Id == userId);
            var touristObject = await _context.TouristObjects
                .FirstOrDefaultAsync(x => x.Id == id);
            user.ReservedObjects.Add(touristObject);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(DetailedObject), new {id});
        }
        [Authorize]
        [HttpGet]
        [Route("unreserve/{id}")]
        public async Task<IActionResult> RemoveFromReserved(int id)
        {
            var userId = HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = await _context.Users
                .Include(x => x.ReservedObjects)
                .FirstOrDefaultAsync(x => x.Id == userId);
            var toRemove = user.ReservedObjects.FirstOrDefault(x => x.Id == id);
            user.ReservedObjects.Remove(toRemove);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(DetailedObject), new { id });
        }
    }
}
