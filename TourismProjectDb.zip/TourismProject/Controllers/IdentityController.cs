﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using TourismProject.Models;
using TourismProjectDb.Models;

namespace TourismProject.Controllers
{
    public class IdentityController : Controller
    {
        private readonly SignInManager<User> _signInManager;
        private readonly UserManager<User> _userManager;
        public IdentityController(
            SignInManager<User> signInManager,
            UserManager<User> userManager)
        {
            _signInManager = signInManager;
            _userManager = userManager;
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginModel loginModel)
        {
            var result = await _signInManager.PasswordSignInAsync(loginModel.UserName, 
                loginModel.Password, 
                loginModel.IsRememberMeChecked, 
                false);
            if (result.Succeeded)
            {
                return RedirectToAction(
                    nameof(TouristObjectsController.AllObjects),
                    "TouristObjects");
            }
            ModelState.AddModelError("", "Неверный логин или пароль");
            return View(nameof(LoginPage), loginModel);
        }
        [HttpGet]
        [Route("/login")]
        public IActionResult LoginPage()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(RegisterModel registerModel)
        {
            if (registerModel.PasswordRepeated != registerModel.Password)
            {
                ModelState.AddModelError(string.Empty, "Пароли не одинаковы");
            }
            if (!ModelState.IsValid)
            {
                return View(nameof(RegisterPage), registerModel);
            }
            var user = new User()
            {
                UserName = registerModel.Username,
                Email = registerModel.Email,
            };
            var result = await _userManager.CreateAsync(user, registerModel.Password);

            if (result.Succeeded)
            {
                return RedirectToAction(nameof(LoginPage));
            }

            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }

            return View(nameof(RegisterPage), registerModel);
        }
        [HttpGet]
        [Route("/register")]
        public IActionResult RegisterPage()
        {
            return View();
        }
        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction(
                    nameof(TouristObjectsController.AllObjects),
                    "TouristObjects");
        }
    }
}
