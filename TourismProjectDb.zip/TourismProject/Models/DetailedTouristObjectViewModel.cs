﻿namespace TourismProject.Models
{
    public class DetailedTouristObjectViewModel
    {
        public required int Id { get; set; }
        public required string Name { get; set; }
        public required string ImagePath { get; set; }
        public required decimal Price { get; set; }
        public required string Description { get; set; }
        public required bool IsReservedByUser { get; set; }
    }
}
