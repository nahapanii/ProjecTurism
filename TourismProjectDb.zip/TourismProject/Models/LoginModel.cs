﻿using System.ComponentModel.DataAnnotations;

namespace TourismProject.Models
{
    public class LoginModel
    {
        [Required(ErrorMessage = "Не введено имя пользователя")]
        public required string UserName { get; set; }
        [Required(ErrorMessage = "Не введен пароль")]
        [DataType(DataType.Password)]
        public required string Password { get; set; }
        public required bool IsRememberMeChecked { get; set; }
    }
}
