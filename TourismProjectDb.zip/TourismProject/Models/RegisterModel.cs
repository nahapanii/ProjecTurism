﻿using System.ComponentModel.DataAnnotations;

namespace TourismProject.Models
{
    public class RegisterModel
    {
        [Required(ErrorMessage = "Не введено имя пользователя")]
        [StringLength(maximumLength: 20, MinimumLength = 6, ErrorMessage = "Длина имени пользователя должна быть между 6 и 20" )]
        public required string Username { get; set; }
        [Required(ErrorMessage = "Не введена почта")]
        [EmailAddress(ErrorMessage = "Некорректно введена почта")]
        public required string Email { get; set; }
        [Required(ErrorMessage = "Не введен пароль")]
        [DataType(DataType.Password)]
        [StringLength(20, MinimumLength = 6, ErrorMessage = "Длина пароля должна быть между 6 и 20 символами")]
        [RegularExpression(@"^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$", ErrorMessage = "Пароль должен содержать хотя бы одну букву, одну цифру и один специальный символ (@$!%*?&)")]
        public required string Password { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public required string PasswordRepeated { get; set; }
    }
}
